<?php

namespace Config;

use CodeIgniter\Config\BaseConfig;

class App extends BaseConfig
{
    /**
     * Base URL — change this to your server's URL
     * e.g. 'http://localhost/quiz-ci4-final/'
     */
    public string $baseURL = 'http://localhost/quiz-ci4-final/';

    /**
     * Allowed Hostnames (leave empty to allow all)
     */
    public array $allowedHostnames = [];

    public string $indexPage = '';

    public string $uriProtocol = 'REQUEST_URI';

    public string $defaultLocale = 'en';
    public bool   $negotiateLocale = false;
    public array  $supportedLocales = ['en'];

    public string $appTimezone = 'UTC';
    public string $charset     = 'UTF-8';

    public bool $forceGlobalSecureRequests = false;

    /**
     * Session
     */
    public string $sessionDriver            = 'CodeIgniter\Session\Handlers\FileHandler';
    public string $sessionCookieName        = 'ci_session';
    public int    $sessionExpiration        = 7200;
    public string $sessionSavePath          = WRITEPATH . 'session';
    public bool   $sessionMatchIP           = false;
    public int    $sessionTimeToUpdate      = 300;
    public bool   $sessionRegenerateDestroy = false;

    /**
     * Cookie
     */
    public string $cookiePrefix   = '';
    public string $cookieDomain   = '';
    public string $cookiePath     = '/';
    public bool   $cookieSecure   = false;
    public bool   $cookieHTTPOnly = true;
    public string $cookieSameSite = 'Lax';

    /**
     * CSRF
     */
    public bool   $CSRFProtection  = false;   // set to true in production
    public string $CSRFTokenName   = 'csrf_test_name';
    public string $CSRFHeaderName  = 'X-CSRF-TOKEN';
    public string $CSRFCookieName  = 'csrf_cookie_name';
    public int    $CSRFExpire      = 7200;
    public bool   $CSRFRegenerate  = true;
    public array  $CSRFExcludeURIs = [];
    public string $CSRFSameSite    = 'Lax';

    public string $proxyIPs = '';

    public bool $CSPEnabled = false;
}
