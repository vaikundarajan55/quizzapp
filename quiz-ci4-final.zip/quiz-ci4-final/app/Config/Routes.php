<?php

namespace Config;

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

// ---------------------------------------------------------------
// WEBSITE (Public) Routes
// ---------------------------------------------------------------
$routes->get('/', 'WebsiteController::index');
$routes->get('/quiz', 'WebsiteController::quiz');
$routes->get('/quiz/(:num)', 'WebsiteController::quiz/$1');
$routes->post('/quiz/submit', 'WebsiteController::submit');
$routes->get('/results/(:alphanum)', 'WebsiteController::results/$1');
$routes->get('/about', 'WebsiteController::about');

// ---------------------------------------------------------------
// ADMIN Routes (prefix: /admin)
// ---------------------------------------------------------------
$routes->group('admin', ['namespace' => 'App\Controllers'], function ($routes) {
    // Dashboard
    $routes->get('/', 'AdminController::index');
    $routes->get('dashboard', 'AdminController::index');

    // Questions CRUD
    $routes->get('questions', 'AdminController::questions');
    $routes->get('questions/create', 'AdminController::createQuestion');
    $routes->post('questions/store', 'AdminController::storeQuestion');
    $routes->get('questions/edit/(:num)', 'AdminController::editQuestion/$1');
    $routes->post('questions/update/(:num)', 'AdminController::updateQuestion/$1');
    $routes->post('questions/delete/(:num)', 'AdminController::deleteQuestion/$1');
    $routes->post('questions/reorder', 'AdminController::reorderQuestions');

    // Results / Submissions
    $routes->get('results', 'AdminController::results');
    $routes->get('results/(:alphanum)', 'AdminController::resultDetail/$1');
    $routes->post('results/clear', 'AdminController::clearResults');

    // Settings
    $routes->get('settings', 'AdminController::settings');
    $routes->post('settings/save', 'AdminController::saveSettings');

    // API endpoints (AJAX)
    $routes->post('api/toggle-question/(:num)', 'AdminController::toggleQuestion/$1');
});
