<?php

namespace App\Models;

use CodeIgniter\Model;

/**
 * QuizModel
 *
 * Manages quiz questions, options, and submissions.
 * Uses JSON file storage so the app works without a database.
 * Swap out the load/save methods for a real DB if needed.
 */
class QuizModel extends Model
{
    protected string $dataFile;
    protected string $resultsFile;
    protected string $settingsFile;

    public function __construct()
    {
        parent::__construct();
        $this->dataFile    = WRITEPATH . 'quiz_data.json';
        $this->resultsFile = WRITEPATH . 'quiz_results.json';
        $this->settingsFile = WRITEPATH . 'quiz_settings.json';
        $this->seedIfEmpty();
    }

    // ---------------------------------------------------------------
    // QUESTIONS
    // ---------------------------------------------------------------

    public function getAllQuestions(): array
    {
        $data = $this->loadData();
        return $data['questions'] ?? [];
    }

    public function getActiveQuestions(): array
    {
        return array_values(array_filter(
            $this->getAllQuestions(),
            fn($q) => ($q['active'] ?? true) === true
        ));
    }

    public function getQuestion(int $id): ?array
    {
        foreach ($this->getAllQuestions() as $q) {
            if ((int)$q['id'] === $id) return $q;
        }
        return null;
    }

    public function createQuestion(array $data): int
    {
        $all = $this->getAllQuestions();
        $newId = $all ? max(array_column($all, 'id')) + 1 : 1;
        $data['id']     = $newId;
        $data['active'] = true;
        $data['sort']   = count($all) + 1;
        $all[] = $data;
        $this->saveQuestions($all);
        return $newId;
    }

    public function updateQuestion(int $id, array $data): bool
    {
        $all = $this->getAllQuestions();
        foreach ($all as &$q) {
            if ((int)$q['id'] === $id) {
                $q = array_merge($q, $data);
                $this->saveQuestions($all);
                return true;
            }
        }
        return false;
    }

    public function deleteQuestion(int $id): bool
    {
        $all = array_filter($this->getAllQuestions(), fn($q) => (int)$q['id'] !== $id);
        $this->saveQuestions(array_values($all));
        return true;
    }

    public function toggleQuestion(int $id): bool
    {
        $all = $this->getAllQuestions();
        foreach ($all as &$q) {
            if ((int)$q['id'] === $id) {
                $q['active'] = !($q['active'] ?? true);
                $this->saveQuestions($all);
                return $q['active'];
            }
        }
        return false;
    }

    // ---------------------------------------------------------------
    // RESULTS / SUBMISSIONS
    // ---------------------------------------------------------------

    public function saveResult(array $result): string
    {
        $results = $this->loadResults();
        $token = bin2hex(random_bytes(8));
        $result['token']      = $token;
        $result['created_at'] = date('Y-m-d H:i:s');
        $results[] = $result;
        file_put_contents($this->resultsFile, json_encode($results, JSON_PRETTY_PRINT));
        return $token;
    }

    public function getResult(string $token): ?array
    {
        foreach ($this->loadResults() as $r) {
            if ($r['token'] === $token) return $r;
        }
        return null;
    }

    public function getAllResults(): array
    {
        $results = $this->loadResults();
        return array_reverse($results); // newest first
    }

    public function clearResults(): void
    {
        file_put_contents($this->resultsFile, json_encode([], JSON_PRETTY_PRINT));
    }

    public function getStats(): array
    {
        $questions = $this->getAllQuestions();
        $results   = $this->loadResults();
        $total     = count($results);
        $scores    = array_column($results, 'score');
        return [
            'total_questions' => count($questions),
            'active_questions' => count($this->getActiveQuestions()),
            'total_attempts'  => $total,
            'avg_score'       => $total ? round(array_sum($scores) / $total, 1) : 0,
            'high_score'      => $total ? max($scores) : 0,
            'recent_results'  => array_slice(array_reverse($results), 0, 5),
        ];
    }

    // ---------------------------------------------------------------
    // SETTINGS
    // ---------------------------------------------------------------

    public function getSettings(): array
    {
        if (!file_exists($this->settingsFile)) {
            return $this->defaultSettings();
        }
        $s = json_decode(file_get_contents($this->settingsFile), true);
        return array_merge($this->defaultSettings(), $s ?? []);
    }

    public function saveSettings(array $settings): void
    {
        file_put_contents($this->settingsFile, json_encode($settings, JSON_PRETTY_PRINT));
    }

    private function defaultSettings(): array
    {
        return [
            'quiz_title'        => 'Pickup & Drop the Correct Top Mark',
            'quiz_subtitle'     => 'IALA Buoyage System Quiz',
            'voice_enabled'     => true,
            'show_answer_card'  => true,
            'allow_retry'       => true,
            'theme_color'       => '#6c5ce7',
            'bg_type'           => 'ocean', // ocean | gradient | plain
            'questions_per_quiz'=> 0,       // 0 = all active
            'passing_score'     => 70,
        ];
    }

    // ---------------------------------------------------------------
    // PRIVATE HELPERS
    // ---------------------------------------------------------------

    private function loadData(): array
    {
        if (!file_exists($this->dataFile)) return [];
        return json_decode(file_get_contents($this->dataFile), true) ?? [];
    }

    private function loadResults(): array
    {
        if (!file_exists($this->resultsFile)) return [];
        return json_decode(file_get_contents($this->resultsFile), true) ?? [];
    }

    private function saveQuestions(array $questions): void
    {
        $data = $this->loadData();
        $data['questions'] = $questions;
        file_put_contents($this->dataFile, json_encode($data, JSON_PRETTY_PRINT));
    }

    /**
     * Seed data from the original data.js if the JSON store is empty.
     */
    private function seedIfEmpty(): void
    {
        if (file_exists($this->dataFile)) return;

        // Build seed from the original quiz data (the 16 questions)
        $seed = [
            'questions' => [
                ['id'=>1,'prompt'=>'Drag the correct top mark onto the IALA Region A Lateral Port Hand Mark.','answerLabel'=>'IALA Region A – Lateral Port Hand Mark (Red Can)','answerCardText'=>'"IALA Region A"\nLateral Port hand Mark\nTop mark Single red can','questionImage'=>'assets/questions/q1.png','options'=>[['file'=>'assets/options/q1_a.png','label'=>'Red Cone','correct'=>false],['file'=>'assets/options/q1_b.png','label'=>'Green Can','correct'=>false],['file'=>'assets/options/q1_c.png','label'=>'Red Can','correct'=>true],['file'=>'assets/options/q1_d.png','label'=>'Green Cone','correct'=>false]],'active'=>true,'sort'=>1],
                ['id'=>2,'prompt'=>'Drag the correct top mark onto the IALA Region A Lateral Starboard Hand Mark.','answerLabel'=>'IALA Region A – Lateral Starboard Hand Mark (Green Cone)','answerCardText'=>'"IALA Region A"\nLateral Starboard hand Mark\nTop mark Single green cone, pointing upward','questionImage'=>'assets/questions/q2.png','options'=>[['file'=>'assets/options/q2_a.png','label'=>'Green Can','correct'=>false],['file'=>'assets/options/q2_b.png','label'=>'Red Can','correct'=>false],['file'=>'assets/options/q2_c.png','label'=>'Green Cone','correct'=>true],['file'=>'assets/options/q2_d.png','label'=>'Red Cone','correct'=>false]],'active'=>true,'sort'=>2],
                ['id'=>3,'prompt'=>'Drag the correct top mark onto the IALA Region B Lateral Port Hand Mark.','answerLabel'=>'IALA Region B – Lateral Port Hand Mark (Green Can)','answerCardText'=>'"IALA Region B"\nLateral Port hand Mark\nTop mark Single green can','questionImage'=>'assets/questions/q3.png','options'=>[['file'=>'assets/options/q3_a.png','label'=>'Green Cone','correct'=>false],['file'=>'assets/options/q3_b.png','label'=>'Red Can','correct'=>false],['file'=>'assets/options/q3_c.png','label'=>'Green Can','correct'=>true],['file'=>'assets/options/q3_d.png','label'=>'Red Cone','correct'=>false]],'active'=>true,'sort'=>3],
                ['id'=>4,'prompt'=>'Drag the correct top mark onto the IALA Region B Lateral Starboard Hand Mark.','answerLabel'=>'IALA Region B – Lateral Starboard Hand Mark (Red Cone)','answerCardText'=>'"IALA Region B"\nLateral Starboard hand Mark\nTop mark Single red cone, pointing upward','questionImage'=>'assets/questions/q4.png','options'=>[['file'=>'assets/options/q4_a.png','label'=>'Red Can','correct'=>false],['file'=>'assets/options/q4_b.png','label'=>'Green Cone','correct'=>false],['file'=>'assets/options/q4_c.png','label'=>'Red Cone','correct'=>true],['file'=>'assets/options/q4_d.png','label'=>'Green Can','correct'=>false]],'active'=>true,'sort'=>4],
                ['id'=>5,'prompt'=>'Drag the correct top mark onto the Safe Water Mark.','answerLabel'=>'Safe Water Mark – Red & White Vertical Stripes, Red Ball Topmark','answerCardText'=>'Safe Water Mark\nTop mark: Single red ball','questionImage'=>'assets/questions/q5.png','options'=>[['file'=>'assets/options/q5_a.png','label'=>'Red Ball','correct'=>true],['file'=>'assets/options/q5_b.png','label'=>'Green Cone','correct'=>false],['file'=>'assets/options/q5_c.png','label'=>'Red Can','correct'=>false],['file'=>'assets/options/q5_d.png','label'=>'X Shape','correct'=>false]],'active'=>true,'sort'=>5],
                ['id'=>6,'prompt'=>'Drag the correct top mark onto the Isolated Danger Mark.','answerLabel'=>'Isolated Danger Mark – Two Black Balls Topmark','answerCardText'=>'Isolated Danger Mark\nTop mark: Two black balls','questionImage'=>'assets/questions/q6.png','options'=>[['file'=>'assets/options/q6_a.png','label'=>'Two Black Balls','correct'=>true],['file'=>'assets/options/q6_b.png','label'=>'Red Ball','correct'=>false],['file'=>'assets/options/q6_c.png','label'=>'Yellow Cone','correct'=>false],['file'=>'assets/options/q6_d.png','label'=>'X Shape','correct'=>false]],'active'=>true,'sort'=>6],
                ['id'=>7,'prompt'=>'Drag the correct top mark onto the North Cardinal Mark.','answerLabel'=>'North Cardinal Mark – Two cones points up','answerCardText'=>'North Cardinal Mark\nTop mark: Two cones, points upward','questionImage'=>'assets/questions/q7.png','options'=>[['file'=>'assets/options/q7_a.png','label'=>'Two cones up','correct'=>true],['file'=>'assets/options/q7_b.png','label'=>'Two cones down','correct'=>false],['file'=>'assets/options/q7_c.png','label'=>'Cones base to base','correct'=>false],['file'=>'assets/options/q7_d.png','label'=>'Cones point to point','correct'=>false]],'active'=>true,'sort'=>7],
                ['id'=>8,'prompt'=>'Drag the correct top mark onto the South Cardinal Mark.','answerLabel'=>'South Cardinal Mark – Two cones points down','answerCardText'=>'South Cardinal Mark\nTop mark: Two cones, points downward','questionImage'=>'assets/questions/q8.png','options'=>[['file'=>'assets/options/q8_a.png','label'=>'Two cones down','correct'=>true],['file'=>'assets/options/q8_b.png','label'=>'Two cones up','correct'=>false],['file'=>'assets/options/q8_c.png','label'=>'Cones base to base','correct'=>false],['file'=>'assets/options/q8_d.png','label'=>'Cones point to point','correct'=>false]],'active'=>true,'sort'=>8],
                ['id'=>9,'prompt'=>'Drag the correct top mark onto the East Cardinal Mark.','answerLabel'=>'East Cardinal Mark – Two cones base to base','answerCardText'=>'East Cardinal Mark\nTop mark: Two cones, base to base','questionImage'=>'assets/questions/q9.png','options'=>[['file'=>'assets/options/q9_a.png','label'=>'Cones base to base','correct'=>true],['file'=>'assets/options/q9_b.png','label'=>'Two cones up','correct'=>false],['file'=>'assets/options/q9_c.png','label'=>'Two cones down','correct'=>false],['file'=>'assets/options/q9_d.png','label'=>'Cones point to point','correct'=>false]],'active'=>true,'sort'=>9],
                ['id'=>10,'prompt'=>'Drag the correct top mark onto the West Cardinal Mark.','answerLabel'=>'West Cardinal Mark – Two cones point to point','answerCardText'=>'West Cardinal Mark\nTop mark: Two cones, point to point','questionImage'=>'assets/questions/q10.png','options'=>[['file'=>'assets/options/q10_a.png','label'=>'Cones point to point','correct'=>true],['file'=>'assets/options/q10_b.png','label'=>'Two cones up','correct'=>false],['file'=>'assets/options/q10_c.png','label'=>'Two cones down','correct'=>false],['file'=>'assets/options/q10_d.png','label'=>'Cones base to base','correct'=>false]],'active'=>true,'sort'=>10],
                ['id'=>11,'prompt'=>'Drag the correct top mark onto the Special Mark.','answerLabel'=>'Special Mark – Yellow X topmark','answerCardText'=>'Special Mark\nTop mark: X shape (yellow)','questionImage'=>'assets/questions/q11.png','options'=>[['file'=>'assets/options/q11_a.png','label'=>'X Shape','correct'=>true],['file'=>'assets/options/q11_b.png','label'=>'Red Ball','correct'=>false],['file'=>'assets/options/q11_c.png','label'=>'Two Black Balls','correct'=>false],['file'=>'assets/options/q11_d.png','label'=>'Green Cone','correct'=>false]],'active'=>true,'sort'=>11],
                ['id'=>12,'prompt'=>'Drag the correct top mark onto the IALA Region A Lateral Port Hand Mark (Light)','answerLabel'=>'IALA Region A Lateral Port Hand Mark with light','answerCardText'=>'"IALA Region A"\nLateral Port hand Mark\nTop mark Single red can\nLight: Red flashing','questionImage'=>'assets/questions/q12.png','options'=>[['file'=>'assets/options/q12_a.png','label'=>'Red Can','correct'=>true],['file'=>'assets/options/q12_b.png','label'=>'Green Can','correct'=>false],['file'=>'assets/options/q12_c.png','label'=>'Red Cone','correct'=>false],['file'=>'assets/options/q12_d.png','label'=>'Green Cone','correct'=>false]],'active'=>true,'sort'=>12],
                ['id'=>13,'prompt'=>'Drag the correct top mark onto this cardinal mark.','answerLabel'=>'Cardinal Mark identification','answerCardText'=>'Cardinal Mark\nIdentify by topmark and light pattern','questionImage'=>'assets/questions/q13.png','options'=>[['file'=>'assets/options/q13_a.png','label'=>'Two cones up','correct'=>true],['file'=>'assets/options/q13_b.png','label'=>'Two cones down','correct'=>false],['file'=>'assets/options/q13_c.png','label'=>'Cones base to base','correct'=>false],['file'=>'assets/options/q13_d.png','label'=>'Cones point to point','correct'=>false]],'active'=>true,'sort'=>13],
                ['id'=>14,'prompt'=>'Drag the correct top mark onto this mark.','answerLabel'=>'Mark identification','answerCardText'=>'Mark identification\nMatch topmark to buoy type','questionImage'=>'assets/questions/q14.png','options'=>[['file'=>'assets/options/q14_a.png','label'=>'Option A','correct'=>true],['file'=>'assets/options/q14_b.png','label'=>'Option B','correct'=>false],['file'=>'assets/options/q14_c.png','label'=>'Option C','correct'=>false],['file'=>'assets/options/q14_d.png','label'=>'Option D','correct'=>false]],'active'=>true,'sort'=>14],
                ['id'=>15,'prompt'=>'Drag the correct top mark onto this mark.','answerLabel'=>'Mark identification','answerCardText'=>'Mark identification\nMatch topmark to buoy type','questionImage'=>'assets/questions/q15.png','options'=>[['file'=>'assets/options/q15_a.png','label'=>'Option A','correct'=>false],['file'=>'assets/options/q15_b.png','label'=>'Option B','correct'=>true],['file'=>'assets/options/q15_c.png','label'=>'Option C','correct'=>false],['file'=>'assets/options/q15_d.png','label'=>'Option D','correct'=>false]],'active'=>true,'sort'=>15],
                ['id'=>16,'prompt'=>'Drag the correct top mark onto this mark.','answerLabel'=>'Mark identification','answerCardText'=>'Mark identification\nMatch topmark to buoy type','questionImage'=>'assets/questions/q16.png','options'=>[['file'=>'assets/options/q16_a.png','label'=>'Option A','correct'=>false],['file'=>'assets/options/q16_b.png','label'=>'Option B','correct'=>false],['file'=>'assets/options/q16_c.png','label'=>'Option C','correct'=>true],['file'=>'assets/options/q16_d.png','label'=>'Option D','correct'=>false]],'active'=>true,'sort'=>16],
            ]
        ];
        file_put_contents($this->dataFile, json_encode($seed, JSON_PRETTY_PRINT));
    }
}
