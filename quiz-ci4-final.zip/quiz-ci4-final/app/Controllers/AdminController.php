<?php

namespace App\Controllers;

use App\Models\QuizModel;
use CodeIgniter\Controller;

class AdminController extends Controller
{
    protected QuizModel $quiz;

    public function __construct()
    {
        $this->quiz = new QuizModel();
        // In production: add auth middleware here
    }

    // ---------------------------------------------------------------
    // Dashboard
    // ---------------------------------------------------------------

    public function index(): string
    {
        $stats    = $this->quiz->getStats();
        $settings = $this->quiz->getSettings();
        return view('admin/dashboard', compact('stats', 'settings'));
    }

    // ---------------------------------------------------------------
    // Questions
    // ---------------------------------------------------------------

    public function questions(): string
    {
        $questions = $this->quiz->getAllQuestions();
        $settings  = $this->quiz->getSettings();
        return view('admin/questions/index', compact('questions', 'settings'));
    }

    public function createQuestion(): string
    {
        $settings = $this->quiz->getSettings();
        return view('admin/questions/form', ['question' => null, 'settings' => $settings]);
    }

    public function storeQuestion()
    {
        $data = $this->buildQuestionData();
        $id   = $this->quiz->createQuestion($data);

        return redirect()->to(base_url('admin/questions'))
            ->with('success', "Question #{$id} created successfully.");
    }

    public function editQuestion(int $id): string
    {
        $question = $this->quiz->getQuestion($id);
        $settings = $this->quiz->getSettings();

        if (!$question) {
            return redirect()->to(base_url('admin/questions'))
                ->with('error', 'Question not found.');
        }

        return view('admin/questions/form', compact('question', 'settings'));
    }

    public function updateQuestion(int $id)
    {
        $data = $this->buildQuestionData();
        $this->quiz->updateQuestion($id, $data);

        return redirect()->to(base_url('admin/questions'))
            ->with('success', "Question #{$id} updated successfully.");
    }

    public function deleteQuestion(int $id)
    {
        $this->quiz->deleteQuestion($id);
        return redirect()->to(base_url('admin/questions'))
            ->with('success', "Question #{$id} deleted.");
    }

    public function reorderQuestions()
    {
        $order = $this->request->getPost('order') ?? [];
        foreach ($order as $sort => $id) {
            $this->quiz->updateQuestion((int)$id, ['sort' => (int)$sort + 1]);
        }
        return $this->response->setJSON(['success' => true]);
    }

    public function toggleQuestion(int $id)
    {
        $active = $this->quiz->toggleQuestion($id);
        return $this->response->setJSON(['success' => true, 'active' => $active]);
    }

    // ---------------------------------------------------------------
    // Results
    // ---------------------------------------------------------------

    public function results(): string
    {
        $results  = $this->quiz->getAllResults();
        $settings = $this->quiz->getSettings();
        return view('admin/results/index', compact('results', 'settings'));
    }

    public function resultDetail(string $token): string
    {
        $result   = $this->quiz->getResult($token);
        $settings = $this->quiz->getSettings();

        if (!$result) {
            return redirect()->to(base_url('admin/results'))
                ->with('error', 'Result not found.');
        }

        return view('admin/results/detail', compact('result', 'settings'));
    }

    public function clearResults()
    {
        $this->quiz->clearResults();
        return redirect()->to(base_url('admin/results'))
            ->with('success', 'All results cleared.');
    }

    // ---------------------------------------------------------------
    // Settings
    // ---------------------------------------------------------------

    public function settings(): string
    {
        $settings = $this->quiz->getSettings();
        return view('admin/settings/index', compact('settings'));
    }

    public function saveSettings()
    {
        $post = $this->request->getPost();
        $settings = [
            'quiz_title'        => $post['quiz_title']        ?? 'Quiz',
            'quiz_subtitle'     => $post['quiz_subtitle']     ?? '',
            'voice_enabled'     => !empty($post['voice_enabled']),
            'show_answer_card'  => !empty($post['show_answer_card']),
            'allow_retry'       => !empty($post['allow_retry']),
            'theme_color'       => $post['theme_color']       ?? '#6c5ce7',
            'bg_type'           => $post['bg_type']           ?? 'ocean',
            'questions_per_quiz'=> (int)($post['questions_per_quiz'] ?? 0),
            'passing_score'     => (int)($post['passing_score']      ?? 70),
        ];
        $this->quiz->saveSettings($settings);

        return redirect()->to(base_url('admin/settings'))
            ->with('success', 'Settings saved successfully.');
    }

    // ---------------------------------------------------------------
    // Private helpers
    // ---------------------------------------------------------------

    private function buildQuestionData(): array
    {
        $post = $this->request->getPost();

        $options = [];
        $optLabels  = $post['opt_label']   ?? [];
        $optFiles   = $post['opt_file']    ?? [];
        $optCorrect = $post['opt_correct'] ?? -1;

        foreach ($optLabels as $i => $label) {
            $options[] = [
                'label'   => $label,
                'file'    => $optFiles[$i] ?? '',
                'correct' => ((int)$optCorrect === $i),
            ];
        }

        return [
            'prompt'        => $post['prompt']        ?? '',
            'answerLabel'   => $post['answerLabel']   ?? '',
            'answerCardText'=> $post['answerCardText'] ?? '',
            'questionImage' => $post['questionImage'] ?? '',
            'options'       => $options,
            'active'        => !empty($post['active']),
        ];
    }
}
