<?php

namespace App\Controllers;

use App\Models\QuizModel;
use CodeIgniter\Controller;

class WebsiteController extends Controller
{
    protected QuizModel $quiz;

    public function __construct()
    {
        $this->quiz = new QuizModel();
    }

    /**
     * Home / landing page
     */
    public function index(): string
    {
        $settings = $this->quiz->getSettings();
        $stats    = $this->quiz->getStats();
        return view('website/home', compact('settings', 'stats'));
    }

    /**
     * Quiz page — loads questions and renders the drag-drop UI
     */
    public function quiz(?int $page = null): string
    {
        $settings  = $this->quiz->getSettings();
        $questions = $this->quiz->getActiveQuestions();

        // Limit questions if setting is applied
        $limit = (int)($settings['questions_per_quiz'] ?? 0);
        if ($limit > 0 && $limit < count($questions)) {
            $questions = array_slice($questions, 0, $limit);
        }

        return view('website/quiz', compact('settings', 'questions'));
    }

    /**
     * Handle quiz submission (AJAX POST from the quiz page)
     */
    public function submit()
    {
        $request = $this->request;
        $answers = $request->getPost('answers') ?? [];
        $elapsed = (int)($request->getPost('elapsed') ?? 0);

        $questions = $this->quiz->getActiveQuestions();
        $total     = count($questions);
        $correct   = 0;
        $details   = [];

        foreach ($questions as $q) {
            $qid      = $q['id'];
            $answered = $answers[$qid] ?? null;
            $isCorrect = false;

            if ($answered !== null) {
                $optIdx   = (int)$answered;
                $isCorrect = !empty($q['options'][$optIdx]['correct']);
            }

            if ($isCorrect) $correct++;
            $details[] = [
                'id'           => $qid,
                'prompt'       => $q['prompt'],
                'answerLabel'  => $q['answerLabel'],
                'answered'     => $answered !== null,
                'optionIndex'  => $answered,
                'correct'      => $isCorrect,
                'correctLabel' => collect($q['options'])->firstWhere('correct', true)['label'] ?? '',
            ];
        }

        $score = $total > 0 ? round(($correct / $total) * 100, 1) : 0;

        $token = $this->quiz->saveResult([
            'total'   => $total,
            'correct' => $correct,
            'score'   => $score,
            'elapsed' => $elapsed,
            'details' => $details,
        ]);

        return $this->response->setJSON([
            'success' => true,
            'token'   => $token,
            'score'   => $score,
            'correct' => $correct,
            'total'   => $total,
        ]);
    }

    /**
     * Results page — show result by token
     */
    public function results(string $token): string
    {
        $result   = $this->quiz->getResult($token);
        $settings = $this->quiz->getSettings();

        if (!$result) {
            return view('errors/404', ['message' => 'Result not found.']);
        }

        return view('website/results', compact('result', 'settings'));
    }

    /**
     * About page
     */
    public function about(): string
    {
        $settings = $this->quiz->getSettings();
        return view('website/about', compact('settings'));
    }
}
