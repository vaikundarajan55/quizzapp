<?php $this->extend('admin/layouts/main') ?>
<?php $this->section('content') ?>
<?php $isEdit = !empty($question); ?>

<div class="page-header">
  <div>
    <h2 class="page-title"><?= $isEdit ? 'Edit Question #' . $question['id'] : 'New Question' ?></h2>
    <p class="page-sub"><?= $isEdit ? 'Update question details and options' : 'Fill in all fields to add a new question' ?></p>
  </div>
  <a href="<?= base_url('admin/questions') ?>" class="btn btn-outline-secondary">
    <i class="fas fa-arrow-left mr-1"></i> Back
  </a>
</div>

<form method="post"
      action="<?= $isEdit ? base_url('admin/questions/update/' . $question['id']) : base_url('admin/questions/store') ?>"
      enctype="multipart/form-data">
  <?= csrf_field() ?>

  <div class="row">
    <!-- Left: Main fields -->
    <div class="col-lg-7">
      <div class="admin-card animate-fadeIn mb-4">
        <div class="admin-card-header">
          <h5><i class="fas fa-info-circle mr-2"></i>Question Details</h5>
        </div>
        <div class="admin-card-body">

          <div class="form-group">
            <label class="form-label-admin">Question Prompt <span class="text-danger">*</span></label>
            <textarea name="prompt" class="form-control admin-input" rows="3" required
                      placeholder="e.g. Drag the correct top mark onto the IALA Region A Lateral Port Hand Mark."
            ><?= esc($question['prompt'] ?? '') ?></textarea>
          </div>

          <div class="form-group">
            <label class="form-label-admin">Answer Label <span class="text-danger">*</span></label>
            <input type="text" name="answerLabel" class="form-control admin-input"
                   value="<?= esc($question['answerLabel'] ?? '') ?>"
                   placeholder="e.g. IALA Region A – Lateral Port Hand Mark (Red Can)" required />
          </div>

          <div class="form-group">
            <label class="form-label-admin">Answer Card Text</label>
            <textarea name="answerCardText" class="form-control admin-input" rows="3"
                      placeholder="Text shown in the answer card & spoken aloud (use \n for newlines)"
            ><?= esc($question['answerCardText'] ?? '') ?></textarea>
            <small class="text-muted">Use \n to separate lines. Color words (red/green) are highlighted automatically.</small>
          </div>

          <div class="form-group">
            <label class="form-label-admin">Question Image Path <span class="text-danger">*</span></label>
            <div class="input-group">
              <input type="text" name="questionImage" id="questionImagePath"
                     class="form-control admin-input"
                     value="<?= esc($question['questionImage'] ?? '') ?>"
                     placeholder="assets/questions/q1.png" required />
              <div class="input-group-append">
                <button type="button" class="btn btn-outline-secondary" onclick="previewImage('questionImagePath','questionImagePreview')">
                  <i class="fas fa-eye"></i>
                </button>
              </div>
            </div>
            <div class="img-preview-box mt-2" id="questionImagePreview">
              <?php if (!empty($question['questionImage'])): ?>
              <img src="<?= base_url($question['questionImage']) ?>" alt="Preview" class="img-preview-thumb" />
              <?php else: ?>
              <span class="text-muted small">Preview will appear here</span>
              <?php endif; ?>
            </div>
          </div>

          <div class="form-group form-check mt-3">
            <input type="checkbox" class="form-check-input" name="active" id="activeCheck" value="1"
                   <?= ($question['active'] ?? true) ? 'checked' : '' ?>>
            <label class="form-check-label" for="activeCheck">Active (visible to quiz takers)</label>
          </div>
        </div>
      </div>
    </div>

    <!-- Right: Options -->
    <div class="col-lg-5">
      <div class="admin-card animate-fadeIn mb-4" style="animation-delay:.1s">
        <div class="admin-card-header">
          <h5><i class="fas fa-list-ul mr-2"></i>Answer Options</h5>
          <span class="badge badge-info">Exactly 4 options</span>
        </div>
        <div class="admin-card-body">
          <p class="text-muted small mb-3">
            <i class="fas fa-info-circle mr-1"></i>
            Set the image path for each option and mark which one is correct.
          </p>

          <?php
          $defaultOptions = [
            ['label'=>'Option A','file'=>'','correct'=>false],
            ['label'=>'Option B','file'=>'','correct'=>false],
            ['label'=>'Option C','file'=>'','correct'=>true],
            ['label'=>'Option D','file'=>'','correct'=>false],
          ];
          $opts = $question['options'] ?? $defaultOptions;
          $correctIdx = 0;
          foreach ($opts as $i => $opt) {
            if (!empty($opt['correct'])) { $correctIdx = $i; break; }
          }
          ?>

          <div class="option-list" id="optionList">
            <?php foreach ($opts as $i => $opt): ?>
            <div class="option-item <?= !empty($opt['correct']) ? 'option-correct' : '' ?>" id="optItem<?= $i ?>">
              <div class="option-header">
                <div class="option-letter"><?= chr(65 + $i) ?></div>
                <div class="option-radio-wrap">
                  <input type="radio" name="opt_correct" value="<?= $i ?>"
                         id="correct<?= $i ?>"
                         <?= !empty($opt['correct']) ? 'checked' : '' ?>
                         onchange="highlightCorrect(<?= $i ?>)" />
                  <label for="correct<?= $i ?>" class="correct-radio-label">✓ Correct</label>
                </div>
              </div>
              <div class="form-group mb-2">
                <input type="text" name="opt_label[]" class="form-control admin-input admin-input-sm"
                       value="<?= esc($opt['label']) ?>" placeholder="Label (e.g. Red Can)" />
              </div>
              <div class="input-group input-group-sm">
                <input type="text" name="opt_file[]"
                       class="form-control admin-input admin-input-sm opt-file-input"
                       id="optFile<?= $i ?>"
                       value="<?= esc($opt['file']) ?>"
                       placeholder="assets/options/q1_<?= chr(97+$i) ?>.png" />
                <div class="input-group-append">
                  <button type="button" class="btn btn-outline-secondary btn-sm"
                          onclick="previewOptionImage(<?= $i ?>)">
                    <i class="fas fa-eye"></i>
                  </button>
                </div>
              </div>
              <div class="opt-img-preview mt-1" id="optPreview<?= $i ?>">
                <?php if (!empty($opt['file'])): ?>
                <img src="<?= base_url($opt['file']) ?>" class="opt-preview-thumb" alt="Option <?= chr(65+$i) ?>" />
                <?php endif; ?>
              </div>
            </div>
            <?php endforeach; ?>
          </div>
        </div>
      </div>

      <!-- Submit -->
      <div class="admin-card animate-fadeIn mb-4" style="animation-delay:.2s">
        <div class="admin-card-body">
          <button type="submit" class="btn btn-admin-primary btn-block">
            <i class="fas fa-save mr-1"></i>
            <?= $isEdit ? 'Update Question' : 'Save Question' ?>
          </button>
          <a href="<?= base_url('admin/questions') ?>" class="btn btn-outline-secondary btn-block mt-2">
            Cancel
          </a>
        </div>
      </div>
    </div>
  </div>
</form>

<?php $this->endSection() ?>

<?php $this->section('scripts') ?>
<script>
function highlightCorrect(idx) {
  document.querySelectorAll('.option-item').forEach((el, i) => {
    el.classList.toggle('option-correct', i === idx);
  });
}

function previewImage(inputId, previewId) {
  const path = document.getElementById(inputId).value.trim();
  const box  = document.getElementById(previewId);
  if (!path) return;
  box.innerHTML = `<img src="<?= base_url('/') ?>${path}" alt="Preview" class="img-preview-thumb" onerror="this.src='';this.alt='Image not found'" />`;
}

function previewOptionImage(idx) {
  const path = document.getElementById('optFile' + idx).value.trim();
  const box  = document.getElementById('optPreview' + idx);
  if (!path) return;
  box.innerHTML = `<img src="<?= base_url('/') ?>${path}" alt="Option" class="opt-preview-thumb" onerror="this.alt='Not found'" />`;
}

// Auto-preview question image when path changes
document.getElementById('questionImagePath').addEventListener('blur', function() {
  previewImage('questionImagePath', 'questionImagePreview');
});

// Auto-preview option images on blur
document.querySelectorAll('.opt-file-input').forEach((inp, i) => {
  inp.addEventListener('blur', () => previewOptionImage(i));
});
</script>
<?php $this->endSection() ?>
