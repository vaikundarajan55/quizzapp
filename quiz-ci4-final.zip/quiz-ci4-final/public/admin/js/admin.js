/* =====================================================
   QUIZ APP — ADMIN JS
   ===================================================== */

document.addEventListener('DOMContentLoaded', function () {

  /* ---- Sidebar toggle ---- */
  const sidebar  = document.getElementById('adminSidebar');
  const overlay  = document.getElementById('sidebarOverlay');
  const toggle   = document.getElementById('sidebarToggle');

  function openSidebar()  { sidebar.classList.add('open'); overlay.classList.add('show'); }
  function closeSidebar() { sidebar.classList.remove('open'); overlay.classList.remove('show'); }

  if (toggle)  toggle.addEventListener('click', () => sidebar.classList.contains('open') ? closeSidebar() : openSidebar());
  if (overlay) overlay.addEventListener('click', closeSidebar);

  /* ---- Live clock ---- */
  const clock = document.getElementById('topbarClock');
  if (clock) {
    function tick() {
      const now = new Date();
      clock.textContent = now.toLocaleTimeString('en-GB', { hour12: false });
    }
    tick();
    setInterval(tick, 1000);
  }

  /* ---- Auto-dismiss flash alerts ---- */
  document.querySelectorAll('.alert-floating').forEach(el => {
    // auto-dismiss after 4s
    setTimeout(() => el.style.opacity = '0', 4000);
    setTimeout(() => el.remove(),             4400);
    el.querySelector('.close-alert')?.addEventListener('click', () => el.remove());
  });

  /* ---- Tooltip init ---- */
  if (typeof $ !== 'undefined' && $.fn.tooltip) {
    $('[title]').tooltip({ trigger: 'hover', delay: { show: 300, hide: 0 } });
  }
});

/* ---- Toast helper (usable from inline scripts) ---- */
function showToast(msg, type = 'success') {
  const colors = {
    success: 'linear-gradient(135deg, #059669, #10b981)',
    error:   'linear-gradient(135deg, #dc2626, #ef4444)',
    info:    'linear-gradient(135deg, #1d4ed8, #3b82f6)',
  };
  const t = document.createElement('div');
  t.className = 'alert-floating';
  t.style.cssText = `background:${colors[type] || colors.success};animation:slideInRight .3s ease`;
  t.innerHTML = `<i class="fas fa-${type === 'error' ? 'times' : 'check'}-circle"></i> ${msg}
    <button class="close-alert" onclick="this.parentElement.remove()"><i class="fas fa-times"></i></button>`;
  document.body.appendChild(t);
  setTimeout(() => { t.style.opacity = '0'; setTimeout(() => t.remove(), 400); }, 3500);
}

/* ---- copyUrl (used by dashboard) ---- */
function copyUrl() {
  const el = document.getElementById('quizUrl');
  if (!el) return;
  navigator.clipboard.writeText(el.textContent.trim()).then(() => showToast('Quiz URL copied to clipboard!'));
}
